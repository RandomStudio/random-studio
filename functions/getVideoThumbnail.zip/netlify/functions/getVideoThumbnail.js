var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target, mod));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/getVideoThumbnail.ts
var getVideoThumbnail_exports = {};
__export(getVideoThumbnail_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(getVideoThumbnail_exports);
var import_sharp = __toESM(require("sharp"));
var getImage = async (url) => {
  const response = await fetch(url);
  return Buffer.from(await response.arrayBuffer());
};
var handler = async (event) => {
  const { thumbnailUrl } = event.queryStringParameters;
  const image = await getImage(thumbnailUrl);
  try {
    const buffer = await (0, import_sharp.default)(image).raw().ensureAlpha().resize(12, 12, { fit: "inside" }).toFormat(import_sharp.default.format.png).toBuffer();
    return {
      statusCode: 200,
      body: JSON.stringify({
        buffer: buffer.toString("base64")
      })
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});

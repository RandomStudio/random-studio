var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/getVideoData.ts
var getVideoData_exports = {};
__export(getVideoData_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(getVideoData_exports);

// src/utils/videoUtils.ts
var getFunctionUrl = (path) => {
  const host = process.env.NEXT_PUBLIC_NETLIFY_FUNCTIONS_BASE_URL ?? (typeof window === "undefined" ? "http://localhost:3000" : window.location.host);
  const url = new URL(path, host);
  return url.href;
};
var getVideoThumbnail = async (url) => {
  const response = await fetch(getFunctionUrl(`/.netlify/functions/getVideoThumbnail?thumbnailUrl=${url}`));
  const { buffer } = await response.json();
  return buffer;
};
var formatVideoData = async (details) => {
  const { guid, width, height, thumbnailFileName } = details;
  const baseUrl = `https://videos.random.studio/${guid}`;
  const thumbnailUrl = `${baseUrl}/${thumbnailFileName}`;
  const data = {
    baseUrl,
    blur: await getVideoThumbnail(thumbnailUrl),
    fallback: thumbnailUrl,
    height,
    hls: `${baseUrl}/playlist.m3u8`,
    width
  };
  return data;
};

// netlify/functions/getVideoData.ts
var handler = async (event) => {
  const url = new URL(event.rawUrl);
  url.pathname = "/.netlify/functions/getVideosList";
  const response = await fetch(url.href);
  const items = await response.json();
  const hasSpecifiedId = event.path.split("/").length > 4;
  if (!hasSpecifiedId) {
    return {
      statusCode: 404
    };
  }
  const id = event.path.split("/").at(-1);
  const details = items.find((item) => item.guid === id);
  if (!details) {
    return {
      statusCode: 400
    };
  }
  return {
    statusCode: 200,
    body: JSON.stringify(await formatVideoData(details))
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
